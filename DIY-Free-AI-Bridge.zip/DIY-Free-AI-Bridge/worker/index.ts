export default {
  async fetch(req) {
    return new Response("Hello from DIY-Free-AI-Bridge!");
  }
};