# 3. iOS 快捷指令使用说明
导入 `AI_OneClick.shortcut` 并填写参数即可。
