# 2. Cloudflare Worker 使用说明
## 部署
```bash
wrangler login
wrangler deploy
```